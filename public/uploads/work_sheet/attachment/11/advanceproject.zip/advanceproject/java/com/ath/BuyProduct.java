package com.ath;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ath.classes1.Product1;

/**
 * Servlet implementation class BuyProduct
 */
public class BuyProduct extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public BuyProduct() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		
		PrintWriter out = response.getWriter();
		String pid = request.getParameter("productid");
		String category = request.getParameter("category");
		String pname= request.getParameter("pname");
		String manufacture= request.getParameter("manufacture");
		float price= Float.parseFloat(request.getParameter("price"));
		//int quantity = Integer.parseInt("quantity");
		System.out.println("**********************");
		System.out.println(" pid = "+pid);
		System.out.println("category = "+category);
		System.out.println("Pname =  "+pname);
		System.out.println("Manufacturer = "+manufacture);
		System.out.println("Price = "+price);
		//System.out.println("Price = "+quantity);
	
		
		try{
		
		out.println("<html><body bgcolor=#CCCC99><center>");
        out.println("<b><h3><u><font color = green>You are going to buy it </font></u></h3></b>");
    		
        out.println("<table border=1><tr><th>Category</th><th>ProductId</th>"+
    			"<th>ProductName</th><th>Manufacturer</th><th>UnitPrice</th><th>Quantity</th><th></th></tr>");
        out.println("<tr>");

		 out.println("<td>"+category+"</td>  <td>"+pid+"</td> <td>"+pname+"</td> <td>"+manufacture+"</td> <td>"+price+"</td>");
		 
    
    
    out.println("<td>");
     out.println("<select name= quantity>");
     out.println("<option valu1e=1>1</option>");
     out.println("<option valu1e=2>2</option>");
     out.println("<option valu1e=3>3</option>");
     out.println("<option valu1e=4>4</option>");
     out.println("<option valu1e=5>5</option>");
     out.println("<option valu1e=6>6</option>");
     out.println("<option valu1e=7>7</option>");
     out.println("<option valu1e=8>8</option>");
     out.println("<option valu1e=9>9</option>");
     out.println("<option valu1e=10>10</option>");
     out.println("<option valu1e=11>11</option>");
     out.println("<option valu1e=12>12</option>");
     out.println("<option valu1e=13>13</option>");
     out.println("<option valu1e=14>14</option>");
     out.println("<option valu1e=15>15</option>");
     out.println("<option valu1e=16>16</option>");
     out.println("<option valu1e=17>17</option>");
     out.println("<option valu1e=18>18</option>");
     out.println("<option valu1e=19>19</option>");
     out.println("<option valu1e=20>20</option>");
     out.println("<option valu1e=21>21</option>");
     out.println("<option valu1e=22>22</option>");
     out.println("<option valu1e=23>23</option>");
     out.println("<option valu1e=24>24</option>");
     out.println("<option valu1e=25>25</option>");
     out.println("</select>");  
     out.println("</td>");
	  
   //  float quantity1 = Float.parseFloat(request.getParameterValues(quantity));
     out.println("<td><a href=http://localhost:8080/advanceproject/Payment?category="+category+"&productid="+pid+"&pname="+pname+"&manufacture="+manufacture+"&price="+price+">Proceed To Payment</a></td>");
		
	   
	   out.println(" </tr>");
	   out.println("/<td>");
 out.println("</table>");
 out.println("<br>");
 out.println("<br>");
 
 

out.println("</center></body></html>");
out.close();
    	
    	
		}catch(Exception ex)
		{
			out.println("Select correct Quantity");
		}
    	
    	
	
	
	
	
	
	
	
	
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
