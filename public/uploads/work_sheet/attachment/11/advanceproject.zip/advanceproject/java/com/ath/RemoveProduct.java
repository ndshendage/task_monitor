package com.ath;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.ath.classes1.CartContains1;
import com.ath.classes1.Product1;

/**
 * Servlet implementation class RemoveProduct
 */
public class RemoveProduct extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RemoveProduct() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		PrintWriter out = response.getWriter();
		
		HttpSession session = request.getSession();
		CartContains1 cart =  (CartContains1) session.getAttribute("products");
		
		
		 HashMap<String, Product1> productsInCart = (HashMap<String, Product1>) cart.getCartItems();
			
		 productsInCart = (HashMap<String, Product1>) cart.getCartItems();
		 
		 out.println("Before Removal = "+productsInCart);
		String pid = request.getParameter("productid");
		out.println(" Product Id = "+pid);
		
		
		cart.removeProduct(pid);
		 
		 out.println("After Removal = "+productsInCart);
		 out.println("I am in product removal method");
		
		
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
