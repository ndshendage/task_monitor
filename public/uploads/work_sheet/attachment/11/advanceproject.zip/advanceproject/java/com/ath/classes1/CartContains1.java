package com.ath.classes1;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;



public class CartContains1 {

	Map <String,Product1> productsInCart;

	public CartContains1() {
		super();
		productsInCart = new HashMap<String, Product1>();
		}
	
	
	public boolean addProduct(Product1 p)  {
		if (productsInCart.containsKey(p.getPid()))
		{
			
			Product1 p1 = productsInCart.get(p.getPid());
			
			 System.out.println("product Id "+p1.getPid()+" this item is already in the cart quantity = "+p1.getQuantity());
			 
			 int quantity = p1.getQuantity() + 1;
			 p1.setQuantity(quantity);
			 System.out.println("product Id is = "+p1.getPid()+" quantity = "+p1.getQuantity());
			 
			 return true;
		}
		
		productsInCart.put(p.getPid(), p);
		return false;
	}


	
	
	public Map<String, Product1> getCartItems(){
		return   productsInCart;
	}
	
	
public void removeProduct( String pid)
{  
	 productsInCart.remove(pid);
	 System.out.println("************I am in remove product method ");
	 System.out.println("I received pid = "+pid);
		

}
		
		
	}


