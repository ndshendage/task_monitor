package com.ath;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class RegisterOwnerwervlet
 */
public class RegisterOwnerwervlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RegisterOwnerwervlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	
	
	
	
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		

        PrintWriter out = response.getWriter();
        out.println("<html><body bgcolor=#CCCC99><center>");
        out.println("<br><br><b><h3><u><font color=red>"+"Status of your Registration"+"</font></u></h3></b>");
        out.println("<br>");
        String ownerid = request.getParameter("oid");
			String ownerpass = request.getParameter("opwd");
		
if(ownerid != "" && ownerpass !="")
{
			
		try{
			
			
			
			
  		Class.forName("com.mysql.jdbc.Driver");
          Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/shopping","root","Athdnlt219");
          
          String sql = "insert into owner values(?,?)";
          
          PreparedStatement pstatement = connection.prepareStatement(sql);
		    
          pstatement.setString(1,ownerid);
          pstatement.setString(2,ownerpass);
          pstatement.executeUpdate();
          pstatement.close();
          connection.close();
        out.println("You have successfully registered");
        out.println("<br>");
        out.println("<h4><font color=blue><a href= http://localhost:8080/advanceproject/ownerlogin.html>Click Here</a></font>To Login</h3>");    
    	
          
   
          
		
		
		}catch(ClassNotFoundException exc){
      	   System.out.println("Class has not been found");
             System.out.println("Error message =  "+ exc.getMessage());
             out.println("Please try with another user name"); 
		}catch(SQLException ex){
          	System.out.println("Sql exception has occured");
	        	System.out.println("Error message =  "+ ex.getMessage());
	        	out.println("Username <b>"+ownerid+"</b> exists Already ");    
	        	
	        	out.println("<br>");
	        	out.println("<font color=blue><a href= http://localhost:8080/advanceproject/registeruser.html>Try Again</a></font>");    
	        	out.println("<br>");
	        	out.println("<Font color=Green> With different username");
		}finally{
	        		out.println("</center></body></html>");
	        		out.close();
	        	}
	
	
	
}else {
	out.println("User Name and password cannot be null");
	out.println("<br>");
	out.println("<font color=blue><a href= http://localhost:8080/advanceproject/registerowner.html>Try Again</a></font>");    
	
	
}
	
		
	
	
	
	
	
	
	
	
	}

}
