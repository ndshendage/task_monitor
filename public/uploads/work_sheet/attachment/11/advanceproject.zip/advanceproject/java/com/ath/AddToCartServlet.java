package com.ath;


import java.io.IOException;

import java.io.PrintWriter;
import java.sql.Date;
import java.util.HashMap;
import java.util.Map.Entry;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.ath.classes1.CartContains1;
import com.ath.classes1.Product1;





/**
 * Servlet implementation class AddToCartServlet
 */
public class AddToCartServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AddToCartServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		PrintWriter out = response.getWriter();
		String pid = request.getParameter("productid");
		String category = request.getParameter("category");
		String pname= request.getParameter("pname");
		String manufacture= request.getParameter("manufacture");
		float price= Float.parseFloat(request.getParameter("price"));
		int quantity=1;
		response.setContentType("text/html;charset=UTF-8");
		
		
		
		
		Product1 p = new  Product1(category, pid, pname, manufacture,price,quantity);
	    

		
		HttpSession session = request.getSession();
		
		
		
		CartContains1 cart =  (CartContains1) session.getAttribute("products");
		
		if(cart == null){
	          cart = new CartContains1();
	          session.setAttribute("products", cart);
	        }
		
		
		
		Date createTime = new Date(session.getCreationTime());
		System.out.println("************Date "+createTime);
		
		Date lastAccessTime = 
                new Date(session.getLastAccessedTime());
		System.out.println("************LastDate "+createTime);
		
		
		
		
		
		
		
		
		
		String shop = "Recently added product in your cart";
		out.println("<html><body bgcolor=#CCCC99><center>");
        out.println("<b><h3><u><font color=red>"+shop+"</font></u></h3></b>");
    	
       
		   
		
    	out.println("<table border=1><tr><th>Category</th><th>ProductId</th>"+
    			"<th>ProductName</th><th>Manufacturer</th><th>UnitPrice</th><th>Quantity</th><th></th></tr>");
      
		    
		out.println("<tr>");
           
		    out.println("<td>"+p.getCategory()+"</td> <td>"+p.getPid()+"</td> <td>"+p.getPname()+"</td> <td>"+p.getManufacture()+"</td> <td>"+p.getPrice()+"</td><td>"+p.getQuantity()+"</td>");
  		    
		    quantity = p.getQuantity();
            out.println("<td><a href=http://localhost:8080/advanceproject/BuyProduct?category="+category+"&productid="+pid+"&pname="+pname+"&manufacture="+manufacture+"&price="+price+"&quantity="+quantity+">Buy Now</a></td>");
 		     
            out.println(" </tr>");
  		   out.println(" </table>");
		 
		 cart.addProduct(p);
		 
		 if ( cart.addProduct(p) == true)
		 {
			 System.out.println("**************************************");
			 System.out.println("This product exist in your cart update quantity ");
			 
		 }
		 
  		  HashMap<String, Product1> productsInCart = (HashMap<String, Product1>) cart.getCartItems();
	
		/* out.println("<table border=1><tr><th>Category</th><th>ProductId</th>"+
	    			"<th>ProductName</th><th>Manufacturer</th><th>UnitPrice</th><th></th></tr>");
		 out.println("<br>");
		   */
		//out.println("I am before product Dtails method");
   	  
  		  
  		  System.out.println("Cart contains = "+productsInCart);
       	
	  
  		 out.println("<b><h3><u><font color=red>"+"Your Cart contains"+"</font></u></h3></b>");
     	
  		  out.println("<table>");
  		 out.println("<table border=1><tr><th>Category</th><th>ProductId</th>"+
    			"<th>ProductName</th><th>Manufacturer</th><th>UnitPrice</th><th>Quantity</th><th></th><th></th></tr>");
      
          for (Entry<String, Product1> entry : productsInCart.entrySet()) 
          { 
        	  CartContains1 c = new CartContains1();
        	  
              String key = entry.getKey();;
              Product1 value = entry.getValue();
              
  		      out.println("<tr>");
  		    //  System.out.println(" "+((Product1) c).getCategory()+"  "+p.getPid()+"  "+p.getPname()+" "+p.getManufacture()+"  "+p.getPrice());
		      
  		      System.out.println(" "+quantity);
              out.println("<td>"+p.getCategory()+"</td> <td>"+p.getPid()+"</td> <td>"+p.getPname()+"</td> <td>"+p.getManufacture()+"</td> <td>"+p.getPrice()+"</td><td>"+p.getQuantity()+"</td>");
  		      
              out.println("<td><a href=http://localhost:8080/advanceproject/BuyProduct?category="+category+"&productid="+pid+"&pname="+pname+"&manufacture="+manufacture+"&price="+price+"&quantity="+quantity+">Buy Now</a></td>");
  		      
             out.println("<td><a href=http://localhost:8080/advanceproject/RemoveProduct?productid="+p.getPid()+">Remove Item</a></td>");
		      
  		      out.println(" </tr>");
              
             }
         
          out.println("</table>");
          
		 
		
		 out.println("</center></body></html>");
 		out.close();
		
	
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		PrintWriter out = response.getWriter();
		out.println("I am in add cart do post method");
		
	}

}
