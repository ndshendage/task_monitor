package com.ath.classes1;

public class Product1 {
    String category;
	String pid;
	String pname;
	String manufacture;
	float price;
	int quantity;
	
	
	public Product1(String category, String pid, String pname, String manufacture, float price, int quantity) {
		super();
		this.category = category;
		this.pid = pid;
		this.pname = pname;
		this.manufacture = manufacture;
		this.price = price;
	    this.quantity = quantity;
	}
	
	
	
	
	
	
	
	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getPid() {
		return pid;
	}
	public void setPid(String pid) {
		this.pid = pid;
	}
	public String getPname() {
		return pname;
	}
	public void setPname(String pname) {
		this.pname = pname;
	}
	public String getManufacture() {
		return manufacture;
	}
	public void setManufacture(String manufacture) {
		this.manufacture = manufacture;
	}
	public float getPrice() {
		return price;
	}
	public void setPrice(float price) {
		this.price = price;
	}
	
	

	
	

}
