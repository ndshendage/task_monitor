package com.ath;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class OwnerLoginServlet2
 */
public class OwnerLoginServlet2 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public OwnerLoginServlet2() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	
PrintWriter out = response.getWriter();
		
		
		try{
    		Class.forName("com.mysql.jdbc.Driver");
           Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/shopping","root","Athdnlt219");
            System.out.println("You have successfully set the connection with database");
            
            String sql = "Select * from owner where oid=? and opwd=? ";
            PreparedStatement pstatement = connection.prepareStatement(sql);
		    
            String oid = request.getParameter("oid");
            String opwd = request.getParameter("opwd");
            
            pstatement.setString(1,oid);
            pstatement.setString(2,opwd);
            
            ResultSet result = pstatement.executeQuery();
            
            
            if(result.next()){
            
            	//out.println("<HTML><HEAD><TITLE> Product manipulation </TITLE></HEAD><body bgcolor=ghostwhite><center><h3><br><a href='http://localhost:8080/advanceproject/ownerproductmanipulation.html'><font color= green>Continue</font></a></h3></center></body></html>");
                response.sendRedirect("ownerproductmanipulation.html");
            	
                	
            	
            	
            }else{out.println("<HTML><HEAD><TITLE> Product manipulation </TITLE></HEAD><body bgcolor=ghostwhite><center><h3>userID or password has no matched<br><a href=http://localhost:8080/advanceproject/ownerlogin.html>TryAgain</a></h3></center></body></html>");
            
            }
		
		
		
		
		
		}catch(ClassNotFoundException exc){
        	   System.out.println("Class has not been found");
               System.out.println("Error message =  "+ exc.getMessage());
            }catch(SQLException ex){
            	System.out.println("Sql exception has occured");
	        	System.out.println("Error message =  "+ ex.getMessage());
	        	}
	
	
	
	
	
	
	
	
	
	
	}

}
