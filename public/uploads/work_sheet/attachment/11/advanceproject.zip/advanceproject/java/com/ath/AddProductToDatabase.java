package com.ath;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class AddProductToDatabase
 */
public class AddProductToDatabase extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AddProductToDatabase() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	
	
	
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		
		String category = request.getParameter("category");
		String pname = request.getParameter("pname");
		String manufacture= request.getParameter("manufacturer");
		float price =Float.parseFloat(request.getParameter("price"));
		String pid = request.getParameter("pid");
		PrintWriter out = response.getWriter();
		/*System.out.println("******************"+category);
		System.out.println("******************"+pid);
		System.out.println("******************"+pname);
		System.out.println("******************"+manufacture);
		System.out.println("******************"+price);
		System.out.println("******************"+(price+100));*/
		String status = "Product Details you have entered";
		if(pname!="" && pid !="" && manufacture !="")
		{
			try{
				
	    		Class.forName("com.mysql.jdbc.Driver");
	            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/shopping","root","Athdnlt219");
	            
	            String sql = "insert into pcategory values(?,?,?,?,?)";
	            
	            PreparedStatement pstatement = connection.prepareStatement(sql);
			    
	            pstatement.setString(1,category);
	            pstatement.setString(2,pid);
	            pstatement.setString(3,pname);
	            pstatement.setString(4,manufacture);
	            pstatement.setFloat(5,price);
	            
	            pstatement.executeUpdate();
	            pstatement.close();
	            connection.close();
	           
	           
	            
	            out.println("<html><body bgcolor=#CCCC99><center>");
	            out.println("<b><h3><u><font color=red>"+status+"</font></u></h3></b>");
	        	
	           
	    		   
	    		
	        	out.println("<table border=1><tr><th>Category</th><th>ProductId</th>"+
	        			"<th>ProductName</th><th>Manufacturer</th><th>UnitPrice</th></tr>");
	          
	    		    
	    		    out.println("<tr>");
	               
	    		    out.println("<td>"+category+"</td> <td>"+pid+"</td> <td>"+pname+"</td> <td>"+manufacture+"</td> <td>"+price+"</td>");
	      		    
	    		  
	                out.println(" </tr>");
	      		    out.println(" </table>");
	    		  
	            
	            
	            
	         
	     
	            
			
			
			}catch(ClassNotFoundException exc){
	        	   System.out.println("Class has not been found");
	               System.out.println("Error message =  "+ exc.getMessage());
	               out.println("Please try with another user name"); 
			
			
			
			
			
			
			}catch(SQLException ex){
	            	
				    
				 String shop1 = " Status of recently added product in your Product Database";
		    		
				 
				    out.println("<html><body bgcolor=#CCCC99><center>");
		            out.println("<b><h3><u><font color=red>"+shop1+"</font></u></h3></b>");
		        	
				
				
				    System.out.println("Sql exception has occured");
		        	System.out.println("Error message =  "+ ex.getMessage());
		        	out.println("Product of Id = <b>"+pid+"</b> exists Already ");    
		        	
		        	out.println("<br>");
		        	out.println("<font color=blue><a href= http://localhost:8080/advanceproject/addnewproduct.html>Try Again</a></font>");    
		        	out.println("<br>");
		        	out.println("<Font color=Green> With different Product Id");
			
			
			}finally{
		        		out.println("</center></body></html>");
		        		out.close();
		        	}
			
			
			
			
			
			
			
			
			
			
			
			
			
		/*	
			
			out.println("<html><title>Add to product database</title><body bgcolor=#CCCC99><center>");
	        out.println("<b><h3><u><font color=red>"+status+"</font></u></h3></b>");
	        out.println("<table border=1><tr><th>Category</th><th>ProductId</th>"+
	    			"<th>ProductName</th><th>Manufacturer</th><th>UnitPrice</th><th></th></tr>");
	      
			
	        out.println("<tr>");
            out.println("<td>"+category+"</td> <td>"+pid+"</td> <td>"+pname+"</td> <td>"+manufacture+"</td> <td>"+price+"</td>");
  		    
            out.println("<td><a href=http://localhost:8080/advanceproject/ProductRemove>Remove Product</a></td>");
  		    out.println(" </tr>");
  		   out.println(" </table>");
			

  		 out.println("</center></body></html>");
  		out.close();
	     */   
	        //out.println("<HTML><HEAD><TITLE>Adding to Database </TITLE></HEAD><h3 ><font color = green>Product Details you have entered</font></h3><br><br><h4><br> 1) Product category ="+category+" <br> 2) Product ID ="+pid+" <br> 3) Product Name ="+pname+" <br> 1) Product manufacturer ="+manufacture+" <br> 5) Product price ="+price+" <br> </h4></center></body></html>");
		    
		} else
		
			out.println("<HTML><HEAD><TITLE>Adding to Database </TITLE></HEAD><body bgcolor=ghostwhite><center>");
			out.println("<h3><font color=red> ENTER VALID DETAILS  </font></h3>" );
			out.println("<h3> <font color=green> HELP </font> </h3> ");
			out.println("<h4> <font color= orange >1) Price should be integer <br> 2) Other entries should not be empty </h4>");
					out.println("<h3><a href='http://localhost:8080/advanceproject/addnewproduct.html'><font color=green>TryAgain </font></a></h3></center></body></html>");
		
		
		
		
	}
	

	
	
	


}
