package com.ath;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class UserLoginServlet
 */
public class UserLoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UserLoginServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		doPost(request, response);
	
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
PrintWriter out = response.getWriter();
 	
String uid = request.getParameter("uid");
String upwd = request.getParameter("upwd");

	try{
    		Class.forName("com.mysql.jdbc.Driver");
           Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/shopping","root","Athdnlt219");
            System.out.println("You have successfully set the connection with database");
            
            String sql = "Select * from user where uid=? and upwd=? ";
            PreparedStatement pstatement = connection.prepareStatement(sql);
		    
          
            
            pstatement.setString(1,uid);
            pstatement.setString(2,upwd);
            
            ResultSet result = pstatement.executeQuery();
            
            if(result.next()){
            	//out.println("<HTML><HEAD><TITLE> Product Selection</TITLE></HEAD><body><center><h3><br><a href='http://localhost:8080/advanceproject/productcategoryselect.html'>Continue</a></h3></center></body></html>");
                HttpSession session = request.getSession();
                		
                
                session.setAttribute("user", uid);
                
                System.out.println("in servlet login "+uid);
            	response.sendRedirect("productcategoryselect.html");
            }else{out.println("<HTML><HEAD><TITLE> New Document </TITLE></HEAD><body><center><h3>userID or password has no matched<br><a href='http://localhost:8080/advanceproject/userlogin2.html'>TryAgain</a></h3></center></body></html>");
            
            }
		
		
		
		
		
		}catch(ClassNotFoundException exc){
        	   System.out.println("Class has not been found");
               System.out.println("Error message =  "+ exc.getMessage());
            }catch(SQLException ex){
            	System.out.println("Sql exception has occured");
	        	System.out.println("Error message =  "+ ex.getMessage());
	        	}
	
	
	

	
}
	
	
	
	
	
		
		
		
		
	}


