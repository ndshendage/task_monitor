package com.ath;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class ProductCategoryServlet
 */
public class ProductCategoryServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ProductCategoryServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String category = request.getParameter("category");
		System.out.println("you have selected "+ category+" as prouct category");
		HttpSession  session = request.getSession();
		
     PrintWriter out = response.getWriter();
		
     String user = (String) session.getAttribute("user");
     System.out.println("@@@@@@@@@@@@@@@@@@@@@@@@@"+user);
   System.out.println("********************ProductCategoryServlet");

		try{
    		Class.forName("com.mysql.jdbc.Driver");
           Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/shopping","root","Athdnlt219");
            System.out.println("You have successfully set the connection with database");
            
            String sql = "Select * from pcategory where category = ?";
            PreparedStatement pstatement = connection.prepareStatement(sql);
		   
            pstatement.setString(1,category);
            out.println("<html><body bgcolor=#CCCC99><center>");
            out.println("<b><h3><u><font color=red>"+category+"</font></u></h3></b>");
        	out.println("<br>");
        	out.println("<table border=1><tr><th>ProductId</th>"+
        			"<th>ProductName</th><th>Manufacturer</th><th>UnitPrice</th><th>Add To  Cart </th><th>Buy It</th></tr>");
          
            ResultSet rs = pstatement.executeQuery();
             while(rs.next())
             {   int column=2;
            	 out.println("<tr>");
     			 String pid=rs.getString(column);															 
     			 String pname=rs.getString(column+1);
     			 String manufactured=rs.getString(column+2);
     			 float pprice=Float.parseFloat(rs.getString(column+3));
     			
    			 out.println("<td>"+pid+"</td><td>"+pname+"</td><td>"+manufactured+"</td><td>"+pprice+"</td>");
    			 
    		out.println("<td><a href=http://localhost:8080/advanceproject/AddToCartServlet?category="+category+"&productid="+pid+"&pname="+pname+"&manufacture="+manufactured+"&price="+pprice+">Add to cart</a></td>");
    		
            out.println("<td><a href=http://localhost:8080/advanceproject/BuyProduct?category="+category+"&productid="+pid+"&pname="+pname+"&manufacture="+manufactured+"&price="+pprice+">Buy Now</a></td>");
 		      		
  out.println("</tr>");
            	 
            	 
            //	 
             }
            
            
            
            

		}catch(ClassNotFoundException exc){
        	   System.out.println("Class has not been found");
               System.out.println("Error message =  "+ exc.getMessage());
            }catch(SQLException ex){
            	System.out.println("Sql exception has occured");
	        	System.out.println("Error message =  "+ ex.getMessage());
	        	}finally{
	        		out.println("</center></body></html>");
	        		out.close();
	        	}
	
	
     
	
	
	
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
	}

}
